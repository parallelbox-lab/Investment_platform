<?php
require_once('controller.php');
echo generatecode();
?>