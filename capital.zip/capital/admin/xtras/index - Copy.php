<script language="javascript">
window.location="../index.php"
</script>

<?php 
header ("location: ../index.php");
exit;
?>