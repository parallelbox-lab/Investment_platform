<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>ACCESS DENIED</title>
<style type="text/css">
body {
	background-color: #245819;
}
</style>
</head>

<body style="text-align: center; font-size: xx-large; color: #000000; font-weight: bold;">
<p>&nbsp;</p>
<p><img src="<?php echo "http://".$_SERVER['HTTP_HOST']."/img/logo-small-grey.png"?>" width="50" height="50" alt=""/></p>
<span style="color: #FFFFFF">ACCESS TO THIS PAGE IS DENIED </span>
</body>
</html>